const TIMELINE = [
  {
    year: '2024 — now',
    title: 'Frontend Developer',
    place: 'Freelance',
    desc: 'Building modern web applications for clients using React, TypeScript, and Node.js. Focused on clean code architecture and stunning UIs.',
  },
  {
    year: '2023',
    title: 'Started Full-Stack Journey',
    place: 'Self-taught',
    desc: 'Deep dive into web development: mastered JavaScript fundamentals, React ecosystem, Node.js backend development.',
  },
  {
    year: '2022',
    title: 'First lines of code',
    place: 'Beginning',
    desc: 'Started with HTML/CSS, Python fundamentals. Built first static websites and fell in love with creating things for the web.',
  },
];

const ABILITIES = [
  { icon: '⚡', title: 'Fast Learner', desc: 'Quickly adapts to new technologies and frameworks' },
  { icon: '🎨', title: 'Eye for Design', desc: 'Building visually appealing, pixel-perfect interfaces' },
  { icon: '🔧', title: 'Problem Solver', desc: 'Breaking down complex problems into simple solutions' },
  { icon: '📦', title: 'Clean Code', desc: 'Writing readable, maintainable, well-structured code' },
  { icon: '🚀', title: 'Performance First', desc: 'Optimizing apps for speed and great user experience' },
  { icon: '🤝', title: 'Collaborative', desc: 'Works great in teams, communicates clearly' },
];

export default function Resume() {
  return (
    <section id="resume" style={{ padding: '7rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ marginBottom: '4rem' }}>
        <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--accent)', marginBottom: '0.5rem' }}>
          ABOUT & RESUME
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 5vw, 3.5rem)',
          fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--text)', lineHeight: 1,
        }}>
          My story &<br />
          <span style={{
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>experience</span>
        </h2>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '4rem',
        alignItems: 'start',
      }}>
        {/* Left - timeline */}
        <div>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontSize: '0.8rem',
            color: 'var(--text-muted)', letterSpacing: '0.15em',
            marginBottom: '2rem', textTransform: 'uppercase',
          }}>
            Timeline
          </h3>

          <div style={{ position: 'relative' }}>
            <div style={{
              position: 'absolute', left: 0, top: 0, bottom: 0,
              width: '1px', background: 'var(--border)',
            }} />

            {TIMELINE.map((item, i) => (
              <div key={i} style={{
                paddingLeft: '2rem', marginBottom: '2.5rem',
                position: 'relative',
              }}>
                <div style={{
                  position: 'absolute', left: -5, top: 6,
                  width: 10, height: 10, borderRadius: '50%',
                  background: 'var(--bg)', border: '2px solid var(--accent)',
                  boxShadow: '0 0 8px var(--accent)',
                }} />
                <div style={{
                  fontSize: '0.68rem', letterSpacing: '0.1em',
                  color: 'var(--accent)', marginBottom: '0.3rem',
                  fontFamily: 'var(--font-mono)',
                }}>
                  {item.year}
                </div>
                <div style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '1rem', fontWeight: 600,
                  color: 'var(--text)', marginBottom: '0.2rem',
                }}>
                  {item.title}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--accent2)', marginBottom: '0.5rem' }}>
                  {item.place}
                </div>
                <p style={{ fontSize: '0.78rem', lineHeight: 1.65, color: 'var(--text-muted)' }}>
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Right - abilities */}
        <div>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontSize: '0.8rem',
            color: 'var(--text-muted)', letterSpacing: '0.15em',
            marginBottom: '2rem', textTransform: 'uppercase',
          }}>
            Abilities
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            {ABILITIES.map((a) => (
              <div key={a.title} style={{
                padding: '1.4rem',
                background: 'var(--card-bg)',
                border: '1px solid var(--border)',
                borderRadius: '4px',
                transition: 'all 0.2s',
                cursor: 'default',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'rgba(108,99,255,0.35)';
                e.currentTarget.style.background = 'rgba(108,99,255,0.07)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)';
                e.currentTarget.style.background = 'var(--card-bg)';
              }}
              >
                <div style={{ fontSize: '1.5rem', marginBottom: '0.6rem' }}>{a.icon}</div>
                <div style={{
                  fontFamily: 'var(--font-display)', fontSize: '0.8rem',
                  fontWeight: 600, color: 'var(--text)', marginBottom: '0.3rem',
                }}>{a.title}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                  {a.desc}
                </div>
              </div>
            ))}
          </div>

          {/* Bio box */}
          <div style={{
            marginTop: '2rem', padding: '1.5rem',
            background: 'rgba(108,99,255,0.06)',
            border: '1px solid rgba(108,99,255,0.2)',
            borderRadius: '4px',
            position: 'relative',
          }}>
            <div style={{
              position: 'absolute', top: '-0.6rem', left: '1.2rem',
              padding: '0 0.5rem', background: 'var(--bg)',
              fontSize: '0.65rem', letterSpacing: '0.15em',
              color: 'var(--accent)',
            }}>
              ABOUT ME
            </div>
            <p style={{ fontSize: '0.8rem', lineHeight: 1.75, color: 'var(--text-dim)' }}>
              I'm a passionate full-stack developer who loves building beautiful, 
              functional web experiences. I enjoy the challenge of turning complex 
              ideas into clean, elegant code. Always learning, always building.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
