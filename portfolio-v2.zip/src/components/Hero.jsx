import { useEffect, useRef } from 'react';

export default function Hero() {
  const gridRef = useRef(null);

  useEffect(() => {
    const onMove = (e) => {
      if (!gridRef.current) return;
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      gridRef.current.style.backgroundPosition = `${x * 40}px ${y * 40}px`;
    };
    window.addEventListener('mousemove', onMove);
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  return (
    <section id="hero" style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center',
      position: 'relative', overflow: 'hidden', padding: '0 2.5rem',
    }}>
      {/* Background grid */}
      <div ref={gridRef} style={{
        position: 'absolute', inset: 0, zIndex: 0,
        backgroundImage: `
          linear-gradient(rgba(108,99,255,0.06) 1px, transparent 1px),
          linear-gradient(90deg, rgba(108,99,255,0.06) 1px, transparent 1px)
        `,
        backgroundSize: '60px 60px',
        transition: 'background-position 0.1s linear',
      }} />

      {/* Glow blobs */}
      <div style={{
        position: 'absolute', top: '15%', right: '10%',
        width: 500, height: 500, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(108,99,255,0.12) 0%, transparent 70%)',
        filter: 'blur(40px)', zIndex: 0,
      }} />
      <div style={{
        position: 'absolute', bottom: '20%', left: '5%',
        width: 350, height: 350, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(255,101,132,0.1) 0%, transparent 70%)',
        filter: 'blur(40px)', zIndex: 0,
      }} />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 900 }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.6rem',
          padding: '0.3rem 0.9rem',
          border: '1px solid var(--border)',
          borderRadius: '100px',
          marginBottom: '2rem',
          fontSize: '0.7rem', letterSpacing: '0.15em',
          color: 'var(--text-dim)',
          background: 'rgba(108,99,255,0.06)',
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            background: 'var(--accent3)',
            boxShadow: '0 0 8px var(--accent3)',
            animation: 'pulse 2s ease-in-out infinite',
          }} />
          AVAILABLE FOR WORK
        </div>

        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(2.8rem, 8vw, 6.5rem)',
          fontWeight: 900, lineHeight: 0.95,
          letterSpacing: '-0.04em',
          marginBottom: '1.5rem',
        }}>
          <span style={{ display: 'block', color: 'var(--text)' }}>FULL</span>
          <span style={{
            display: 'block',
            WebkitTextStroke: '1px rgba(255,255,255,0.25)',
            color: 'transparent',
          }}>STACK</span>
          <span style={{
            display: 'block',
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}>DEV</span>
        </h1>

        <p style={{
          fontSize: '0.9rem', lineHeight: 1.8,
          color: 'var(--text-dim)', maxWidth: 520,
          marginBottom: '3rem',
          fontFamily: 'var(--font-mono)',
        }}>
          Crafting digital experiences with clean code and bold design.
          React · Node.js · TypeScript — making ideas real.
        </p>

        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <a href="#projects" style={{
            padding: '0.85rem 2rem',
            background: 'var(--accent)',
            color: '#fff',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.8rem', letterSpacing: '0.1em',
            borderRadius: '2px',
            transition: 'all 0.2s',
            boxShadow: '0 0 24px rgba(108,99,255,0.4)',
          }}
          onMouseEnter={e => e.currentTarget.style.boxShadow = '0 0 40px rgba(108,99,255,0.7)'}
          onMouseLeave={e => e.currentTarget.style.boxShadow = '0 0 24px rgba(108,99,255,0.4)'}
          >
            VIEW WORK →
          </a>
          <a href="#contact" style={{
            padding: '0.85rem 2rem',
            border: '1px solid var(--border)',
            color: 'var(--text-dim)',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.8rem', letterSpacing: '0.1em',
            borderRadius: '2px',
            transition: 'all 0.2s',
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--text)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-dim)'; }}
          >
            CONTACT ME
          </a>
        </div>

        {/* Stats row */}
        <div style={{
          display: 'flex', gap: '3rem',
          marginTop: '5rem', paddingTop: '2rem',
          borderTop: '1px solid var(--border)',
        }}>
          {[
            { val: '2+', label: 'Years coding' },
            { val: '10+', label: 'Projects built' },
            { val: '∞', label: 'Coffee consumed' },
          ].map(s => (
            <div key={s.label}>
              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '1.8rem',
                fontWeight: 700, color: 'var(--accent)', letterSpacing: '-0.03em',
              }}>{s.val}</div>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', letterSpacing: '0.1em', marginTop: '0.2rem' }}>
                {s.label.toUpperCase()}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(0.8); }
        }
      `}</style>
    </section>
  );
}
