export default function Contact() {
  return (
    <>
      <section id="contact" style={{
        padding: '7rem 2.5rem 5rem',
        maxWidth: 1100, margin: '0 auto',
        textAlign: 'center',
      }}>
        <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--accent)', marginBottom: '0.5rem' }}>
          GET IN TOUCH
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(2.5rem, 7vw, 5rem)',
          fontWeight: 900, letterSpacing: '-0.04em',
          lineHeight: 0.95, marginBottom: '1.5rem',
          color: 'var(--text)',
        }}>
          Let's build<br />
          <span style={{
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>something great</span>
        </h2>

        <p style={{
          fontSize: '0.85rem', lineHeight: 1.7,
          color: 'var(--text-dim)', maxWidth: 480, margin: '0 auto 3rem',
        }}>
          Open to collaborations, freelance projects, or full-time opportunities.
          Let's connect and make something awesome.
        </p>

        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginBottom: '5rem' }}>
          <a
            href="https://github.com/AREKKUZZERA"
            target="_blank" rel="noreferrer"
            style={{
              display: 'flex', alignItems: 'center', gap: '0.6rem',
              padding: '0.9rem 2rem',
              background: 'var(--accent)',
              color: '#fff', borderRadius: '2px',
              fontSize: '0.8rem', letterSpacing: '0.1em',
              fontFamily: 'var(--font-mono)',
              transition: 'all 0.2s',
              boxShadow: '0 0 24px rgba(108,99,255,0.4)',
            }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = '0 0 40px rgba(108,99,255,0.7)'}
            onMouseLeave={e => e.currentTarget.style.boxShadow = '0 0 24px rgba(108,99,255,0.4)'}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            GITHUB ↗
          </a>

          <a
            href="mailto:arekkuzzera@example.com"
            style={{
              display: 'flex', alignItems: 'center', gap: '0.6rem',
              padding: '0.9rem 2rem',
              border: '1px solid var(--border)',
              color: 'var(--text-dim)', borderRadius: '2px',
              fontSize: '0.8rem', letterSpacing: '0.1em',
              fontFamily: 'var(--font-mono)',
              transition: 'all 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent2)'; e.currentTarget.style.color = 'var(--accent2)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-dim)'; }}
          >
            ✉ EMAIL ME
          </a>
        </div>

        {/* Divider */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '3rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <span style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.1rem', fontWeight: 700,
              color: 'var(--accent)', letterSpacing: '-0.02em',
            }}>
              AREK<span style={{ color: 'var(--accent2)' }}>.</span>
            </span>

            <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
              Built with React + Vite. Deployed on Vercel.
            </p>

            <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
              © {new Date().getFullYear()} AREKKUZZERA
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
