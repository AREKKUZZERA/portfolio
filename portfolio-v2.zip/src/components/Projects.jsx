import { useEffect, useState } from 'react';

const GITHUB_USER = 'AREKKUZZERA';

const LANG_COLORS = {
  JavaScript: '#f7df1e',
  TypeScript: '#3178c6',
  Python: '#ffd43b',
  HTML: '#e34f26',
  CSS: '#563d7c',
  Vue: '#42b883',
  Shell: '#89e051',
  default: '#6c63ff',
};

function ProjectCard({ repo }) {
  const [hovered, setHovered] = useState(false);
  const langColor = LANG_COLORS[repo.language] || LANG_COLORS.default;

  return (
    <a
      href={repo.html_url}
      target="_blank" rel="noreferrer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'block',
        background: hovered ? 'rgba(108,99,255,0.08)' : 'var(--card-bg)',
        border: `1px solid ${hovered ? 'rgba(108,99,255,0.4)' : 'var(--border)'}`,
        borderRadius: '4px',
        padding: '1.8rem',
        transition: 'all 0.25s ease',
        transform: hovered ? 'translateY(-3px)' : 'none',
        boxShadow: hovered ? '0 12px 40px rgba(108,99,255,0.15)' : 'none',
        cursor: 'pointer',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {hovered && (
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: '1px',
          background: 'linear-gradient(90deg, transparent, var(--accent), transparent)',
        }} />
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.8rem' }}>
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: '0.9rem', fontWeight: 600,
          color: hovered ? 'var(--accent)' : 'var(--text)',
          letterSpacing: '-0.01em',
          transition: 'color 0.2s',
          wordBreak: 'break-word', flex: 1, marginRight: '1rem',
        }}>
          {repo.name}
        </div>
        <span style={{
          fontSize: '1rem', opacity: hovered ? 1 : 0.4,
          transition: 'opacity 0.2s, transform 0.2s',
          transform: hovered ? 'translate(2px, -2px)' : 'none',
        }}>↗</span>
      </div>

      <p style={{
        fontSize: '0.78rem', lineHeight: 1.65,
        color: 'var(--text-muted)', marginBottom: '1.5rem',
        minHeight: '3rem',
      }}>
        {repo.description || 'No description provided.'}
      </p>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {repo.language && (
            <>
              <span style={{
                width: 10, height: 10, borderRadius: '50%',
                background: langColor, boxShadow: `0 0 6px ${langColor}88`,
              }} />
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{repo.language}</span>
            </>
          )}
        </div>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>★ {repo.stargazers_count}</span>
          <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>⑂ {repo.forks_count}</span>
        </div>
      </div>
    </a>
  );
}

export default function Projects() {
  const [repos, setRepos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    fetch(`/api/users/${GITHUB_USER}/repos?per_page=50&sort=updated`)
      .then(r => {
        if (!r.ok) throw new Error('GitHub API error');
        return r.json();
      })
      .then(data => {
        const filtered = data
          .filter(r => !r.fork)
          .sort((a, b) => b.stargazers_count - a.stargazers_count);

        setRepos(filtered);
        setLoading(false);
      })
      .catch(e => {
        setError(e.message);
        setLoading(false);
      });
  }, []);

  const langs = ['All', ...new Set(repos.map(r => r.language).filter(Boolean))];
  const displayed = filter === 'All' ? repos : repos.filter(r => r.language === filter);

  return (
    <section id="projects" style={{ padding: '7rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ marginBottom: '3rem' }}>
        <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--accent)', marginBottom: '0.5rem' }}>
          MY WORK
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 5vw, 3.5rem)',
          fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--text)', lineHeight: 1,
        }}>
          Projects &<br />
          <span style={{
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>repositories</span>
        </h2>
      </div>

      {/* Filter pills */}
      {!loading && !error && (
        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap', marginBottom: '2.5rem' }}>
          {langs.map(lang => (
            <button key={lang} onClick={() => setFilter(lang)} style={{
              padding: '0.3rem 0.9rem',
              border: `1px solid ${filter === lang ? 'var(--accent)' : 'var(--border)'}`,
              background: filter === lang ? 'rgba(108,99,255,0.15)' : 'transparent',
              color: filter === lang ? 'var(--accent)' : 'var(--text-muted)',
              borderRadius: '100px', fontSize: '0.7rem', letterSpacing: '0.08em',
              cursor: 'pointer', fontFamily: 'var(--font-mono)',
              transition: 'all 0.2s',
            }}>
              {lang}
            </button>
          ))}
        </div>
      )}

      {loading && (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
          <div style={{ marginBottom: '1rem', animation: 'spin 1s linear infinite', display: 'inline-block' }}>◌</div>
          <div>Loading from GitHub...</div>
        </div>
      )}

      {error && (
        <div style={{
          padding: '2rem', border: '1px solid rgba(255,101,132,0.3)',
          borderRadius: '4px', color: 'var(--accent2)', fontSize: '0.8rem',
          background: 'rgba(255,101,132,0.05)',
        }}>
          Could not load repos: {error}. Check your internet connection or GitHub rate limits.
        </div>
      )}

      {!loading && !error && (
        <>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '1.5rem',
          }}>
            {displayed.map(repo => <ProjectCard key={repo.id} repo={repo} />)}
          </div>

          <div style={{ textAlign: 'center', marginTop: '3rem' }}>
            <a href={`https://github.com/${GITHUB_USER}?tab=repositories`} target="_blank" rel="noreferrer"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.8rem 2rem',
                border: '1px solid var(--border)',
                borderRadius: '2px', fontSize: '0.78rem',
                color: 'var(--text-dim)', letterSpacing: '0.1em',
                transition: 'all 0.2s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-dim)'; }}
            >
              ALL REPOS ON GITHUB ↗
            </a>
          </div>
        </>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </section>
  );
}
