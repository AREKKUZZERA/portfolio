const STACK = {
  'Frontend': [
    { name: 'React', level: 90, color: '#61dafb' },
    { name: 'TypeScript', level: 80, color: '#3178c6' },
    { name: 'JavaScript', level: 92, color: '#f7df1e' },
    { name: 'Next.js', level: 75, color: '#fff' },
    { name: 'Tailwind CSS', level: 85, color: '#38bdf8' },
    { name: 'HTML/CSS', level: 95, color: '#e34f26' },
  ],
  'Backend': [
    { name: 'Node.js', level: 82, color: '#68a063' },
    { name: 'Express', level: 80, color: '#fff' },
    { name: 'Python', level: 70, color: '#ffd43b' },
    { name: 'REST API', level: 85, color: '#6c63ff' },
  ],
  'Tools & DB': [
    { name: 'Git / GitHub', level: 88, color: '#f05032' },
    { name: 'MongoDB', level: 72, color: '#47a248' },
    { name: 'PostgreSQL', level: 65, color: '#336791' },
    { name: 'Docker', level: 60, color: '#2496ed' },
    { name: 'Vite', level: 88, color: '#bd34fe' },
  ],
};

function SkillBar({ name, level, color }) {
  return (
    <div style={{ marginBottom: '1.1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
        <span style={{ fontSize: '0.78rem', color: 'var(--text)' }}>{name}</span>
        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
          {level}%
        </span>
      </div>
      <div style={{
        height: '3px', background: 'rgba(255,255,255,0.06)',
        borderRadius: '2px', overflow: 'hidden',
      }}>
        <div style={{
          height: '100%', width: `${level}%`,
          background: `linear-gradient(90deg, ${color}99, ${color})`,
          borderRadius: '2px',
          boxShadow: `0 0 8px ${color}66`,
          transition: 'width 1.2s ease',
        }} />
      </div>
    </div>
  );
}

export default function Stack() {
  return (
    <section id="stack" style={{
      padding: '7rem 2.5rem', maxWidth: 1100, margin: '0 auto',
    }}>
      <div style={{ marginBottom: '4rem' }}>
        <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--accent)', marginBottom: '0.5rem' }}>
          TECH STACK
        </p>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 5vw, 3.5rem)',
          fontWeight: 700, letterSpacing: '-0.03em',
          color: 'var(--text)', lineHeight: 1,
        }}>
          What I work<br />
          <span style={{
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>with</span>
        </h2>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '2rem',
      }}>
        {Object.entries(STACK).map(([cat, skills]) => (
          <div key={cat} style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--border)',
            borderRadius: '4px',
            padding: '2rem',
            position: 'relative',
            overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', top: 0, left: 0, right: 0, height: '2px',
              background: 'linear-gradient(90deg, var(--accent), var(--accent2))',
            }} />
            <h3 style={{
              fontFamily: 'var(--font-display)',
              fontSize: '0.85rem', fontWeight: 600,
              color: 'var(--text-dim)', letterSpacing: '0.12em',
              marginBottom: '1.8rem',
              textTransform: 'uppercase',
            }}>{cat}</h3>
            {skills.map(s => <SkillBar key={s.name} {...s} />)}
          </div>
        ))}
      </div>

      {/* Icons row */}
      <div style={{
        marginTop: '3rem', padding: '2rem',
        border: '1px solid var(--border)', borderRadius: '4px',
        display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center',
        background: 'var(--card-bg)',
      }}>
        {[
          'React','TypeScript','Node.js','Next.js','Python','MongoDB',
          'PostgreSQL','Docker','Git','Vite','Tailwind','Express'
        ].map(tech => (
          <span key={tech} style={{
            padding: '0.35rem 0.9rem',
            border: '1px solid var(--border)',
            borderRadius: '100px',
            fontSize: '0.72rem', color: 'var(--text-dim)',
            letterSpacing: '0.05em',
            transition: 'all 0.2s',
            cursor: 'default',
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = 'var(--accent)';
            e.currentTarget.style.color = 'var(--accent)';
            e.currentTarget.style.background = 'rgba(108,99,255,0.08)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = 'var(--border)';
            e.currentTarget.style.color = 'var(--text-dim)';
            e.currentTarget.style.background = 'transparent';
          }}
          >
            {tech}
          </span>
        ))}
      </div>
    </section>
  );
}
