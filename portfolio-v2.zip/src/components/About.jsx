export default function About() {
  return (
    <section id="about" style={{
      padding: '0 2.5rem 7rem',
      maxWidth: 1100, margin: '0 auto',
    }}>
      {/* Scrolling text marquee */}
      <div style={{
        overflow: 'hidden',
        borderTop: '1px solid var(--border)',
        borderBottom: '1px solid var(--border)',
        padding: '1rem 0',
        marginBottom: '5rem',
      }}>
        <div style={{
          display: 'flex', gap: '3rem',
          animation: 'marquee 20s linear infinite',
          whiteSpace: 'nowrap',
        }}>
          {['React Developer', 'Node.js', 'TypeScript', 'Clean Code', 'UI Design', 'Problem Solver',
            'React Developer', 'Node.js', 'TypeScript', 'Clean Code', 'UI Design', 'Problem Solver',
            'React Developer', 'Node.js', 'TypeScript', 'Clean Code', 'UI Design', 'Problem Solver',
          ].map((t, i) => (
            <span key={i} style={{
              fontSize: '0.75rem', letterSpacing: '0.2em', color: i % 6 === 0 ? 'var(--accent)' : 'var(--text-muted)',
              textTransform: 'uppercase',
            }}>
              {t} {i % 6 === 0 ? '◆' : '·'}
            </span>
          ))}
        </div>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '3rem', alignItems: 'center',
      }}>
        <div>
          <p style={{ fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--accent)', marginBottom: '0.5rem' }}>
            WHO I AM
          </p>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(1.8rem, 4vw, 3rem)',
            fontWeight: 700, letterSpacing: '-0.03em',
            color: 'var(--text)', lineHeight: 1.1,
            marginBottom: '1.5rem',
          }}>
            Passionate developer<br />based in Russia
          </h2>
          <p style={{
            fontSize: '0.85rem', lineHeight: 1.8,
            color: 'var(--text-dim)', marginBottom: '1.5rem',
          }}>
            I'm a self-taught full-stack developer with a love for building clean,
            performant web applications. From interactive frontends to robust backends,
            I bring ideas to life with code.
          </p>
          <p style={{
            fontSize: '0.85rem', lineHeight: 1.8,
            color: 'var(--text-dim)',
          }}>
            When I'm not coding, I'm exploring new technologies, contributing to open 
            source projects, and continuously leveling up my skills.
          </p>
        </div>

        {/* Code snippet decorative */}
        <div style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--border)',
          borderRadius: '6px',
          overflow: 'hidden',
          fontFamily: 'var(--font-mono)',
          fontSize: '0.78rem',
        }}>
          {/* Window bar */}
          <div style={{
            padding: '0.8rem 1rem',
            borderBottom: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', gap: '0.5rem',
            background: 'rgba(255,255,255,0.02)',
          }}>
            <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ff5f56' }} />
            <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ffbd2e' }} />
            <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#27c93f' }} />
            <span style={{ marginLeft: '1rem', fontSize: '0.68rem', color: 'var(--text-muted)' }}>
              developer.ts
            </span>
          </div>
          {/* Code */}
          <div style={{ padding: '1.5rem' }}>
            {[
              { n: 1, c: <><span style={{color:'#c792ea'}}>const</span> <span style={{color:'#82aaff'}}>developer</span> = {'{'}</> },
              { n: 2, c: <><span style={{paddingLeft:'1.5rem',color:'#f07178'}}>name</span><span style={{color:'#89ddff'}}>:</span> <span style={{color:'#c3e88d'}}>"AREKKUZZERA"</span>,</> },
              { n: 3, c: <><span style={{paddingLeft:'1.5rem',color:'#f07178'}}>role</span><span style={{color:'#89ddff'}}>:</span> <span style={{color:'#c3e88d'}}>"Full Stack Dev"</span>,</> },
              { n: 4, c: <><span style={{paddingLeft:'1.5rem',color:'#f07178'}}>stack</span><span style={{color:'#89ddff'}}>:</span> [<span style={{color:'#c3e88d'}}>"React"</span>, <span style={{color:'#c3e88d'}}>"Node"</span>],</> },
              { n: 5, c: <><span style={{paddingLeft:'1.5rem',color:'#f07178'}}>available</span><span style={{color:'#89ddff'}}>:</span> <span style={{color:'#ff9d00'}}>true</span>,</> },
              { n: 6, c: <><span style={{paddingLeft:'1.5rem',color:'#f07178'}}>coffee</span><span style={{color:'#89ddff'}}>:</span> <span style={{color:'#c3e88d'}}>"always"</span></> },
              { n: 7, c: <>{'}'}<span style={{color:'#89ddff'}}>;</span></> },
            ].map(row => (
              <div key={row.n} style={{ display: 'flex', gap: '1.5rem', lineHeight: 1.8 }}>
                <span style={{ color: 'var(--text-muted)', userSelect: 'none', minWidth: '1rem' }}>{row.n}</span>
                <span>{row.c}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-33.33%); }
        }
      `}</style>
    </section>
  );
}
