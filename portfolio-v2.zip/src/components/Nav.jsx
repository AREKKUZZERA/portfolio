import { useState, useEffect } from 'react';

const links = [
  { href: '#about', label: 'about' },
  { href: '#stack', label: 'stack' },
  { href: '#projects', label: 'projects' },
  { href: '#resume', label: 'resume' },
  { href: '#contact', label: 'contact' },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [active] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      padding: '1.2rem 2.5rem',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      background: scrolled ? 'rgba(10,10,15,0.92)' : 'transparent',
      backdropFilter: scrolled ? 'blur(16px)' : 'none',
      borderBottom: scrolled ? '1px solid var(--border)' : 'none',
      transition: 'all 0.4s ease',
    }}>
      <a href="#" style={{
        fontFamily: 'var(--font-display)',
        fontSize: '1rem', fontWeight: 700,
        color: 'var(--accent)', letterSpacing: '-0.02em',
      }}>
        dmbzzr<span style={{ color: 'var(--accent2)' }}>.</span>
      </a>

      <div style={{ display: 'flex', gap: '2rem' }}>
        {links.map(l => (
          <a key={l.href} href={l.href} style={{
            fontSize: '0.75rem', letterSpacing: '0.12em',
            color: active === l.href ? 'var(--accent)' : 'var(--text-dim)',
            textTransform: 'uppercase',
            transition: 'color 0.2s',
            position: 'relative',
          }}
          onMouseEnter={e => e.target.style.color = 'var(--text)'}
          onMouseLeave={e => e.target.style.color = 'var(--text-dim)'}
          >
            {l.label}
          </a>
        ))}
      </div>

      <a
        href="https://github.com/AREKKUZZERA"
        target="_blank" rel="noreferrer"
        style={{
          fontSize: '0.72rem', letterSpacing: '0.1em',
          padding: '0.4rem 1.1rem',
          border: '1px solid var(--accent)',
          color: 'var(--accent)',
          borderRadius: '2px',
          transition: 'all 0.2s',
        }}
        onMouseEnter={e => { e.target.style.background = 'var(--accent)'; e.target.style.color = '#fff'; }}
        onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = 'var(--accent)'; }}
      >
        GitHub ↗
      </a>
    </nav>
  );
}
