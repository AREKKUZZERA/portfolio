import { useEffect, useRef } from 'react';

export default function Cursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const posRef = useRef({ x: 0, y: 0 });
  const ringPos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e) => {
      posRef.current = { x: e.clientX, y: e.clientY };
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      }
    };

    let raf;
    const animate = () => {
      ringPos.current.x += (posRef.current.x - ringPos.current.x) * 0.12;
      ringPos.current.y += (posRef.current.y - ringPos.current.y) * 0.12;
      if (ringRef.current) {
        ringRef.current.style.transform = `translate(${ringPos.current.x}px, ${ringPos.current.y}px)`;
      }
      raf = requestAnimationFrame(animate);
    };

    window.addEventListener('mousemove', onMove);
    raf = requestAnimationFrame(animate);

    const onHover = () => ringRef.current?.classList.add('hovered');
    const onLeave = () => ringRef.current?.classList.remove('hovered');

    document.querySelectorAll('a, button, [data-cursor]').forEach(el => {
      el.addEventListener('mouseenter', onHover);
      el.addEventListener('mouseleave', onLeave);
    });

    return () => {
      window.removeEventListener('mousemove', onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      <style>{`
        .cursor-dot {
          position: fixed; top: 0; left: 0; pointer-events: none; z-index: 9999;
          width: 6px; height: 6px; background: var(--accent);
          border-radius: 50%; margin: -3px 0 0 -3px;
          transition: background 0.2s;
        }
        .cursor-ring {
          position: fixed; top: 0; left: 0; pointer-events: none; z-index: 9998;
          width: 36px; height: 36px; border: 1.5px solid rgba(108,99,255,0.5);
          border-radius: 50%; margin: -18px 0 0 -18px;
          transition: width 0.3s, height 0.3s, margin 0.3s, border-color 0.3s;
        }
        .cursor-ring.hovered {
          width: 56px; height: 56px; margin: -28px 0 0 -28px;
          border-color: var(--accent);
        }
      `}</style>
      <div ref={dotRef} className="cursor-dot" />
      <div ref={ringRef} className="cursor-ring" />
    </>
  );
}
